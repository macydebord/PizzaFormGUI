public class PizzaGUIRunner
{
    public static void main(String[] args)
    {
        PizzaGUIFrame frame = new PizzaGUIFrame();
        frame.setVisible(true);
    }
}
