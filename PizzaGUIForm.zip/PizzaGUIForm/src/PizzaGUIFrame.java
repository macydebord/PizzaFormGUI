import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

public class PizzaGUIFrame extends JFrame implements ActionListener
{
    private JRadioButton thinCrustRadioButton, regularCrustRadioButton, deepDishCrustRadioButton;
    private JComboBox<String> sizeComboBox;
    private JCheckBox[] toppingsCheckBoxes;
    private JTextArea orderTextArea;
    private JButton orderButton, clearButton, quitButton;

    private static final double[] SIZE_PRICES = {8.00, 12.00, 16.00, 20.00};
    private static final String[] SIZE_OPTIONS = {"Small", "Medium", "Large", "Super"};
    private static final String[] TOPPINGS_OPTIONS = {"Jalapenos", "Black Olives", "Onions", "Pepperoni", "Bacon", "Banana Peppers"};

    public PizzaGUIFrame() {
        setTitle("Pizza Order");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel crustPanel = createCrustPanel();
        JPanel sizePanel = createSizePanel();
        JPanel toppingsPanel = createToppingsPanel();
        JPanel orderPanel = createOrderPanel();
        JPanel buttonPanel = createButtonPanel();

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));
        inputPanel.add(crustPanel);
        inputPanel.add(sizePanel);
        inputPanel.add(toppingsPanel);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(inputPanel, BorderLayout.NORTH);
        centerPanel.add(orderPanel, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
    }

    private JPanel createCrustPanel()
    {
        JPanel crustPanel = new JPanel(new FlowLayout());
        crustPanel.setBorder(BorderFactory.createTitledBorder("Crust"));
        thinCrustRadioButton = new JRadioButton("Thin");
        regularCrustRadioButton = new JRadioButton("Regular");
        deepDishCrustRadioButton = new JRadioButton("Deep-dish");
        ButtonGroup crustGroup = new ButtonGroup();
        crustGroup.add(thinCrustRadioButton);
        crustGroup.add(regularCrustRadioButton);
        crustGroup.add(deepDishCrustRadioButton);
        crustPanel.add(thinCrustRadioButton);
        crustPanel.add(regularCrustRadioButton);
        crustPanel.add(deepDishCrustRadioButton);
        return crustPanel;
    }

    private JPanel createSizePanel()
    {
        JPanel sizePanel = new JPanel(new FlowLayout());
        sizePanel.setBorder(BorderFactory.createTitledBorder("Size"));
        sizeComboBox = new JComboBox<>(SIZE_OPTIONS);
        sizePanel.add(sizeComboBox);
        return sizePanel;
    }

    private JPanel createToppingsPanel()
    {
        JPanel toppingsPanel = new JPanel(new GridLayout(0, 1));
        toppingsPanel.setBorder(BorderFactory.createTitledBorder("Toppings"));
        toppingsCheckBoxes = new JCheckBox[TOPPINGS_OPTIONS.length];
        for (int i = 0; i < TOPPINGS_OPTIONS.length; i++)
        {
            toppingsCheckBoxes[i] = new JCheckBox(TOPPINGS_OPTIONS[i]);
            toppingsPanel.add(toppingsCheckBoxes[i]);
        }
        JScrollPane scrollPane = new JScrollPane(toppingsPanel);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        return toppingsPanel;
    }

    private JPanel createOrderPanel()
    {
        JPanel orderPanel = new JPanel(new BorderLayout());
        orderPanel.setBorder(BorderFactory.createTitledBorder("Order"));
        orderTextArea = new JTextArea(10, 30);
        orderTextArea.setEditable(false);
        orderPanel.add(new JScrollPane(orderTextArea), BorderLayout.CENTER);
        return orderPanel;
    }

    private JPanel createButtonPanel()
    {
        JPanel buttonPanel = new JPanel(new FlowLayout());
        orderButton = new JButton("Order");
        clearButton = new JButton("Clear");
        quitButton = new JButton("Quit");
        orderButton.addActionListener(this);
        clearButton.addActionListener(this);
        quitButton.addActionListener(this);
        buttonPanel.add(orderButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(quitButton);
        return buttonPanel;
    }

    private double calculateTotalPrice()
    {
        double totalPrice = SIZE_PRICES[sizeComboBox.getSelectedIndex()];
        for (JCheckBox toppingsCheckBox : toppingsCheckBoxes)
        {
            if (toppingsCheckBox.isSelected())
            {
                totalPrice += 1.00;
            }
        }
        return totalPrice;
    }

    private void displayOrder() {
        StringBuilder orderText = new StringBuilder();
        DecimalFormat df = new DecimalFormat("#.00");

        String crustType = "";
        if (thinCrustRadioButton.isSelected()) {
            crustType = "Thin";
        } else if (regularCrustRadioButton.isSelected()) {
            crustType = "Regular";
        } else if (deepDishCrustRadioButton.isSelected()) {
            crustType = "Deep-dish";
        }

        orderText.append(String.format("%-19s: %s\n", "Type of Crust", crustType));
        orderText.append(String.format("%-25s: %s\n", "Size", sizeComboBox.getSelectedItem()));
        orderText.append("Toppings:\n");
        for (JCheckBox toppingsCheckBox : toppingsCheckBoxes) {
            if (toppingsCheckBox.isSelected()) {
                orderText.append(String.format("%-27s: %s\n", "", toppingsCheckBox.getText()));
            }
        }
        orderText.append("\n");
        double subtotal = calculateTotalPrice();
        double tax = subtotal * 0.07;
        double total = subtotal + tax;
        orderText.append(String.format("%-21s: $%s\n", "Sub-total", df.format(subtotal)));
        orderText.append(String.format("%-22s: $%s\n", "Tax (7%)", df.format(tax)));
        orderText.append("--------------------------------\n");
        orderText.append(String.format("%-24s: $%s\n", "Total", df.format(total)));

        orderTextArea.setText(orderText.toString());
    }




    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == orderButton)
        {
            displayOrder();
        } else if (e.getSource() == clearButton)
        {
            clearForm();
        } else if (e.getSource() == quitButton)
        {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to quit?", "Quit", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION)
                System.exit(0);
        }
    }

    private void clearForm()
    {
        thinCrustRadioButton.setSelected(false);
        regularCrustRadioButton.setSelected(false);
        deepDishCrustRadioButton.setSelected(false);
        sizeComboBox.setSelectedIndex(0);
        for (JCheckBox toppingsCheckBox : toppingsCheckBoxes)
        {
            toppingsCheckBox.setSelected(false);
        }
        orderTextArea.setText("");
    }

    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(() ->
        {
            PizzaGUIFrame frame = new PizzaGUIFrame();
            frame.setVisible(true);
        });
    }
}
